import dabih.main

dabih.main.main()